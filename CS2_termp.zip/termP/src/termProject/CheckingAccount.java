package termProject;

//당좌예금계좌
public class CheckingAccount extends Account {
	private SavingsAccount linkedSavings; //잔액이 모자랄 때, 자동이체가 가능하도록 연계된 저축예금계좌
	private static final long serialVersionUID = 1L;
	
	public CheckingAccount(String ownerID, String accountNumber, double initialBalance) {
	    super(ownerID, accountNumber, "Checking", initialBalance);
	}

	
	//연결될 저축예금계좌 설정
	public void setLinkedSavings(SavingsAccount savings) {
		this.linkedSavings = savings;
	}
	
    // ⭐ toString() 오버라이딩 (부모 Account 클래스의 toString()을 확장)
	@Override
	public String toString() {
        String baseInfo = super.toString();
        
        // 연계된 저축계좌 정보 추가
        String linkedInfo = "";
        if (linkedSavings != null) {
            linkedInfo = String.format(" (연계 저축계좌: %s)", linkedSavings.getAccountNumber());
        }
        
        // 기존 display() 메서드는 제거하고 toString()으로 대체
	    return baseInfo + linkedInfo;
	}

    // // @Override
    // // public String display() { 
    // //     return "[당좌예금계좌] 계좌번호: " + accountNumber
    // //             + " 잔액: " + totalBalance;
    // // }
}