package termProject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class BankClient {
    private Socket socket;
    private PrintWriter writer;
    private BufferedReader reader;

    public BankClient() throws IOException {
        // 서버 IP가 같은 컴퓨터면 localhost, 포트는 BankServer에서 6000 사용 중
        socket = new Socket("localhost", 6000);
        writer = new PrintWriter(socket.getOutputStream(), true);
        reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
    }

    private String sendRequest(String request) throws IOException {
        writer.println(request);
        return reader.readLine();  // 서버에서 한 줄 응답
    }

    // 로그인 (권한 인증)
    public String authenticateUser(String id, String pw) throws IOException {
        // AUTHENTICATE_USER|userID|password
        String response = sendRequest("AUTHENTICATE_USER|" + id + "|" + pw);
        // "MANAGER" / "CUSTOMER" / "INVALID"
        return response;
    }

   
}
