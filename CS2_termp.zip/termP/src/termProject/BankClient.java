package termProject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class BankClient {
	private Socket socket;
	private PrintWriter writer;
	private BufferedReader reader;

	public BankClient() throws IOException {
		// 서버 IP가 같은 컴퓨터면 localhost, 포트는 BankServer에서 6000 사용 중
		socket = new Socket("localhost", 6000);
		writer = new PrintWriter(socket.getOutputStream(), true);
		reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
	}

	private String sendRequest(String request) throws IOException {
		writer.println(request);
		return reader.readLine();  // 서버에서 한 줄 응답
	}

	// 로그인 (권한 인증)
	public String authenticateUser(String id, String pw) throws IOException {
		// AUTHENTICATE_USER|userID|password
		String response = sendRequest("AUTHENTICATE_USER|" + id + "|" + pw);
		// "MANAGER" / "CUSTOMER" / "INVALID"
		return response;
	}
	// 고객 정보 조회
	public String findCustomer(String id) throws IOException {
		// FIND_CUSTOMER|customerID
		String response = sendRequest("FIND_CUSTOMER|" + id);
		return response; // SUCCESS|... 또는 FAIL|...
	}

	// 잔액 조회
	public String findBalance(String accountNumber) throws IOException {
		// FIND_BALANCE|accountNumber
		String response = sendRequest("FIND_BALANCE|" + accountNumber);
		return response; // SUCCESS|잔액 또는 FAIL|...
	}

	// 입금
	public String deposit(String accountNumber, double amount) throws IOException {
		// CREDIT|accountNumber|amount
		String response = sendRequest("CREDIT|" + accountNumber + "|" + amount);
		return response; // SUCCESS 또는 FAIL
	}

	// 출금
	public String withdraw(String accountNumber, String password, double amount) throws IOException {
		// DEBIT|accountNumber|password|amount
		// 비밀번호는 GUI에서 JPasswordField로 입력받은 것을 사용
		String response = sendRequest("DEBIT|" + accountNumber + "|" + password + "|" + amount);
		return response; // SUCCESS 또는 FAIL
	}

	// 계좌 이체
	public String transfer(String fromAccount, String toAccount, String password, double amount) throws IOException {
		// TRANSFER|fromAccount|toAccount|password|amount
		String response = sendRequest("TRANSFER|" + fromAccount + "|" + toAccount + "|" + password + "|" + amount);
		return response; // SUCCESS 또는 FAIL
	}

	// 연결 닫기
	public void close() {
		try {
			if (reader != null) reader.close();
			if (writer != null) writer.close();
			if (socket != null && !socket.isClosed()) socket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
