package termProject;

import java.io.Serializable;
import java.util.Date;
import java.text.SimpleDateFormat; // ⭐ 날짜 포맷팅을 위한 임포트 추가

public abstract class Account implements Serializable {

    protected String ownerId;
    protected String accountNumber;
    protected String accountType;
    protected double totalBalance;
    protected double availableBalance;
    protected Date openDate;

    // ⭐ 날짜 포맷터 (인스턴스별로 생성)
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    public Account(String ownerId, String accountNumber,
                    String accountType, double initialBalance) {
        this.ownerId = ownerId;
        this.accountNumber = accountNumber;
        this.accountType = accountType;
        this.totalBalance = initialBalance;
        this.availableBalance = initialBalance;
        this.openDate = new Date();
    }

    // ----- getter -----
    public String getOwner() {
        return ownerId;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public String getAccountType() {
        return accountType;
    }

    public double getTotalBalance() {
        return totalBalance;
    }

    public double getAvailableBalance() {
        return availableBalance;
    }

    // ----- 입금 / 출금 -----

    public void credit(double amount) {
        if (amount <= 0) return;
        totalBalance += amount;
        availableBalance += amount;
    }

    public boolean debit(double amount) {
        if (amount <= 0) return false;

        if (availableBalance >= amount) {
            totalBalance -= amount;
            availableBalance -= amount;
            return true;
        }
        return false;
    }
    
    // ----- 출력용 (toString 오버라이딩) -----

    /**
     * ATMClientGUI와 BankManagerGUI에서 계좌 정보를 문자열로 보기 좋게 출력하기 위해 사용됩니다.
     */
    @Override // ⭐ toString() 오버라이딩 추가
    public String toString() {
        // 계좌 유형, 계좌번호, 총 잔액, 개설일 정보를 포함
        return String.format("[%s] 계좌번호: %s, 총 잔액: %.2f원, 인출 가능: %.2f원, 개설일: %s",
                accountType, accountNumber, totalBalance, availableBalance, dateFormat.format(openDate));
    }

    // // ----- 기존 display() 메서드는 toString()이 대체하므로 제거함 -----
    // public String display() {
    //      return "계좌번호: " + accountNumber +
    //              ", 유형: " + accountType +
    //              ", 잔액: " + totalBalance + "원";
    // }
}