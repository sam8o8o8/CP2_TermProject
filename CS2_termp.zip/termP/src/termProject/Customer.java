package termProject;
import java.util.*;
import java.io.Serializable; //1. Serializable 임포트추가

public class Customer implements Serializable {
    private String name;          // 고객 이름
    private String customerId;    // 고객 아이디
    private String password;      // 비밀번호(은행 로그인용)
    private String address;       // 주소
    private String phone;         // 연락처
    private List<Account> accounts; // 고객이 소유한 계좌 목록

    // 생성자
    public Customer(String name, String customerId, String password, String address, String phone) {
        this.name = name;
        this.customerId = customerId;
        this.password = password;
        this.address = address;
        this.phone = phone;
        this.accounts = new ArrayList<>();
    }

    // 비밀번호 변경
    public boolean setPassword(String previousPassword, String newPassword) {
        if (!this.password.equals(previousPassword)) {
            System.out.println("이전 비밀번호가 일치하지 않습니다.");
            return false;
        }
        this.password = newPassword;
        System.out.println("비밀번호가 변경되었습니다.");
        return true;
    }

    // 특정 소유 계좌의 발견
    public Account findAccount(String accountNumber) {
        for (Account acc : accounts) {
            if (acc.getAccountNumber().equals(accountNumber)) {
                return acc;
            }
        }
        return null;
    }

    // 새로운 계좌의 추가
    public void addAccount(Account account) {
        accounts.add(account);
    }

    // 소유 계좌의 삭제 (Account 객체로 삭제)
    public void removeAccount(Account account) {
        accounts.remove(account);
    }

    // 소유 계좌의 삭제 (계좌번호로 삭제)
    public void removeAccount(String accountNumber) {
        Account target = null;
        for (Account acc : accounts) {
            if (acc.getAccountNumber().equals(accountNumber)) {
                target = acc;
                break;
            }
        }
        if (target != null) {
            accounts.remove(target);
        }
    }

    // 🔥 여기 수정: 무한 재귀였던 부분
    public List<Account> getAccountList() {
        return accounts;
    }

    // 총 소유 계좌의 수
    public int getNumberOfAccounts() {
        return accounts.size();
    }

    // 소유 계좌 잔액의 합
    public double getTotalBalance() {
        double total = 0;
        for (Account acc : accounts) {
            total += acc.getTotalBalance();
        }
        return total;
    }

    public String getName()       { return name; }
    public String getCustomerId() { return customerId; }
    public String getPassword()   { return password; }
    public String getAddress()    { return address; }
    public String getPhone()      { return phone; }

 // 📌 termProject/Customer.java 파일 내부

 // ... (기존 필드, 생성자, Getter/Setter 메서드 아래에 추가)

 @Override
 public String toString() {
     StringBuilder sb = new StringBuilder();
     sb.append("--- 고객 정보 ---\n");
     sb.append("이름: ").append(this.name).append("\n");
     sb.append("ID: ").append(this.customerId).append("\n");
     sb.append("주소: ").append(this.address).append("\n");
     sb.append("전화번호: ").append(this.phone).append("\n");
     sb.append("--- 계좌 목록 (").append(this.accounts.size()).append("개) ---\n");
     
     // 계좌 목록 출력 (각 계좌의 toString() 호출)
     if (this.accounts.isEmpty()) {
         sb.append("등록된 계좌 없음");
     } else {
         for (Account acc : this.accounts) {
             sb.append(acc.toString()).append("\n");
         }
     }
     return sb.toString();
 }

 // ... (나머지 Customer 클래스 코드)
    
    // ◆ 예전 코드와 호환용 (getCustomerID 에러 방지)
    public String getCustomerID() {
        return getCustomerId();
    }
}
