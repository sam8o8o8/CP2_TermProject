package termProject;

// 저축예금계좌
public class SavingsAccount extends Account {

    private double interestRate;                 // 이자율
    private double maxTransferAmountToChecking;  // (안 써도 되지만 필드만 남김)
    private static final long serialVersionUID = 1L; // 추가 (Serializable 구현 시 권장)

    public SavingsAccount(String ownerId,
                          String accountNumber,
                          double initialBalance,
                          double interestRate,
                          double maxTransferAmountToChecking) {

        super(ownerId, accountNumber, "Savings", initialBalance);
        this.interestRate = interestRate;
        this.maxTransferAmountToChecking = maxTransferAmountToChecking;
    }

    public double getInterestRate() {
        return interestRate;
    }

    public double getMaxTransferAmountToChecking() {
        return maxTransferAmountToChecking;
    }

    // 이자 적용 (어디서 안 쓰면 그냥 놔둬도 되고, 안 쓰면 호출 안 됨)
    public void applyInterest() {
        double interest = totalBalance * interestRate;
        credit(interest);
    }
    
    // ⭐ toString() 오버라이딩 (부모 Account 클래스의 toString()을 확장)
    @Override
    public String toString() {
        String baseInfo = super.toString();
        
        // 이자율과 한도 정보 추가
        String additionalInfo = String.format(", 이자율: %.2f%%, 한도: %.0f원", 
                                              interestRate * 100, maxTransferAmountToChecking);
        
        // 기존 display() 메서드는 제거하고 toString()으로 대체
        return baseInfo + additionalInfo;
    }
}