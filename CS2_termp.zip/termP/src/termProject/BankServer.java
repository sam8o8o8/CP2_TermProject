package termProject;

import java.io.*;
import java.net.*;
import java.util.*;

public class BankServer {
	List<Customer> customerList;
	List<Account> accountList;
	String managerID = "admin";
	String managerPassword = "admin123";

	private long lastAccountNumber = 100000; // 마지막으로 발급된 계좌 번호를 저장
	// 파일에서 로드하는 로직이 loadAccounts()에 추가되었습니다.

	public BankServer() {
		customerList = new ArrayList<>();
		accountList = new ArrayList<>();

		load(); // customerList, accountList 불러오기

		try {
			ServerSocket server = new ServerSocket(6000);
			System.out.println("BankServer is running on port 6000...");
			while (true) {
				Socket clientSocket = server.accept();
				System.out.println("Client connected: " + clientSocket.getInetAddress());
				ClientHandler clientHandler = new ClientHandler(clientSocket, this);
				new Thread(clientHandler).start();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void load() {
		loadCustomers();
		loadAccounts();
	}

	public void save() {
		saveCustomers();
		saveAccounts();
	}

	// ------------------- 고객 로드/세이브 -------------------

	public void loadCustomers() {
		File file = new File("customer.txt");
		if (!file.exists()) {
			try {
				file.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else if (file.length() > 0) {
			try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(file))) {
				customerList = (ArrayList<Customer>) in.readObject();
			} catch (ClassNotFoundException | IOException e) {
				// 파일이 손상되었거나 형식이 맞지 않을 경우 빈 리스트로 초기화
				System.err.println("Error loading customers. Starting with empty list.");
				customerList = new ArrayList<>();
			}
		}
	}

	public synchronized void saveCustomers() {
		try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("customer.txt"))) {
			out.writeObject(customerList);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// ------------------- 계좌 로드/세이브 -------------------

	public synchronized void loadAccounts() {
		File file = new File("account.txt");
		if (!file.exists()) {
			try {
				file.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else if (file.length() > 0) {
			try (ObjectInputStream in =
					new ObjectInputStream(new FileInputStream(file))) {
				accountList = (ArrayList<Account>) in.readObject();
				// 계좌 로드 후, 고객 객체와 다시 연결
				for (Account acc : accountList) {
					Customer owner = findCustomer(acc.getOwner());
					if (owner != null) {
						owner.addAccount(acc);
					}
				}
				// ⭐ 수정: 계좌 로드 후 마지막 계좌 번호 갱신 ⭐
				updateLastAccountNumber();
			} catch (IOException | ClassNotFoundException e) {
				System.err.println("Error loading accounts. Starting with empty list.");
				accountList = new ArrayList<>();
			}
		}
	}

	public synchronized void saveAccounts() {
		try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("account.txt"))) {
			out.writeObject(accountList);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 로드된 accountList에서 가장 큰 계좌 번호를 찾아 lastAccountNumber를 갱신합니다.
	 */
	private void updateLastAccountNumber() {
		long maxNum = 100000;
		for (Account acc : accountList) {
			String accNumStr = acc.getAccountNumber();
			if (accNumStr.startsWith("ACC")) {
				try {
					// "ACC" 접두사를 제외한 숫자 부분만 파싱
					long currentNum = Long.parseLong(accNumStr.substring(3));
					if (currentNum > maxNum) {
						maxNum = currentNum;
					}
				} catch (NumberFormatException e) {
					// 잘못된 포맷의 계좌번호는 무시
				}
			}
		}
		this.lastAccountNumber = maxNum;
	}

	// ------------------- 인증/고객 관리 -------------------

	public synchronized String authenticateUser(String userID, String password) {
		if (userID.equals(managerID) && password.equals(managerPassword)) {
			return "MANAGER";
		}

		Customer customer = findCustomer(userID);
		if (customer != null && customer.getPassword().equals(password)) {
			return "CUSTOMER";
		}

		return "FAIL";
	}


	public synchronized boolean addCustomer(String name, String customerID, String password, String address, String phone) {
		if (findCustomer(customerID) == null) {
			Customer customer = new Customer(name, customerID, password, address, phone);
			customerList.add(customer);
			save();
			return true;
		}
		return false;
	}

	public synchronized boolean deleteCustomer(String customerID) {
		Customer customer = findCustomer(customerID);
		if (customer != null) {
			// 고객의 모든 계좌 삭제
			List<Account> customerAccounts = new ArrayList<>(customer.getAccountList());
			for (Account account : customerAccounts) {
				deleteAccount(account.getAccountNumber());
			}
			customerList.remove(customer);
			save();
			return true;
		}
		return false;
	}

	public synchronized Customer findCustomer(String customerID) {
		for (Customer c : customerList) {
			if (c.getCustomerId().equals(customerID)) {
				return c;
			}
		}
		return null;
	}

	// BankServer.java의 addAccount 메서드 전체
	public synchronized String addAccount(String ownerId, String accountType, double initialBalance, double param1, double param2) {
	    // 1. 고객 존재 여부 확인
	    Customer customer = findCustomer(ownerId);
	    if (customer == null) {
	        return null; // 고객이 없으면 계좌 추가 실패
	    }
	    
	    // 2. 계좌번호 생성 (고유한 번호 생성)
	    String newAccountNumber = generateUniqueAccountNumber(); 
	    
	    // 3. 계좌 객체 생성
	    Account newAccount = null;
	    switch (accountType.toLowerCase()) {
	        case "checking":
	            newAccount = new CheckingAccount(ownerId, newAccountNumber, initialBalance);
	            break;
	        case "savings":
	            newAccount = new SavingsAccount(ownerId, newAccountNumber, initialBalance, param1, param2);
	            break;
	        default:
	            return null; // 알 수 없는 계좌 유형
	    }

	    // 4. 계좌 리스트와 고객 계좌 목록에 추가
	    accountList.add(newAccount);
	    customer.addAccount(newAccount);
	    
	    // 5. 변경사항 저장
	    save();

	    return newAccountNumber;
	}

	private synchronized String generateUniqueAccountNumber() {
	    // 서버가 재시작되어도 lastAccountNumber를 기억하고 증가시킵니다.
	    lastAccountNumber++; 
	    return "ACC" + lastAccountNumber;
	}

	public synchronized boolean deleteAccount(String accountNumber) {
		Account account = findAccount(accountNumber);
		if (account == null) {
			return false;
		}

		Customer customer = findCustomer(account.getOwner());
		if (customer != null) {
			customer.removeAccount(accountNumber);
		}

		accountList.remove(account);
		save();
		return true;
	}

	public synchronized Account findAccount(String accountNumber) {
		for (Account a : accountList) {
			if (a.getAccountNumber().equals(accountNumber)) {
				return a;
			}
		}
		return null;
	}

	public synchronized double findbalance(String accountNumber) {
		Account account = findAccount(accountNumber);
		if (account != null) {
			return account.getTotalBalance();
		}
		return -1;
	}

	public synchronized void deposit(String accountNumber, double amount) {
		Account account = findAccount(accountNumber);
		if (account != null) {
			account.credit(amount);
			save();
		}
	}
	
	// 데모 목적상 비밀번호 검증 없이 출금만 수행
	public synchronized boolean withdraw(String accountNumber, double amount, String password) {
		Account account = findAccount(accountNumber);
		if (account == null) return false;
		// ⚠️ 데모 목적상 비밀번호 검증 로직은 생략 (항상 true)
		// if (!account.checkPassword(password)) return false; 
		
		boolean success = account.debit(amount);
		if (success) {
			save();
		}
		return success;
	}

	// 데모 목적상 비밀번호 검증 없이 이체만 수행
	public synchronized boolean transfer(String fromAccountNumber, String toAccountNumber, double amount, String password) {
		Account fromAccount = findAccount(fromAccountNumber);
		Account toAccount = findAccount(toAccountNumber);

		if (fromAccount == null || toAccount == null || amount <= 0) {
			return false;
		}
		
		// ⚠️ 데모 목적상 비밀번호 검증 로직은 생략 (항상 true)
		// if (!fromAccount.checkPassword(password)) return false; 

		if (fromAccount.debit(amount)) {
			toAccount.credit(amount);
			save();
			return true;
		}
		return false;
	}

	// ------------------- 통계/출력 -------------------

	// 모든 고객 정보 출력 (printCustomerList의 마지막 구분자 제거)
	public synchronized String printCustomerList() {
		StringBuilder sb = new StringBuilder();
		String delimiter = "---CUST-SEP---";
		for (int i = 0; i < customerList.size(); i++) {
			Customer customer = customerList.get(i);
			sb.append("고객이름: ").append(customer.getName())
			.append(", 고객아이디: ").append(customer.getCustomerId())
			.append(", 고객주소: ").append(customer.getAddress())
			.append(", 연락처: ").append(customer.getPhone())
			.append(", 계좌개수: ").append(customer.getNumberOfAccounts());

			// 마지막 요소가 아닐 경우에만 구분자 추가
			if (i < customerList.size() - 1) {
				sb.append(delimiter);
			}
		}
		return sb.toString();
	}

	// BankServer.java 파일 내

	// BankServer.java 파일 내
	
	
	
	// 📌 BankServer.java 파일 내 printAccountList() 메서드

	public synchronized String printAccountList() {
	    StringBuilder sb = new StringBuilder();
	    String lineSeparator = System.lineSeparator();
	    
	    // 1. 제목 추가
	    sb.append("=== 전체 계좌 리스트 ===").append(lineSeparator);

	    // 2. 디버깅 정보 (현재는 콘솔로 출력)
	    // System.out.println("DEBUG: accountList에 현재 저장된 계좌 수: " + accountList.size());
	    
	    // 3. 계좌 목록 출력
	    if (accountList.isEmpty()) {
	        sb.append("등록된 계좌가 없습니다.").append(lineSeparator);
	    } else {
	        for (Account account : accountList) {
	            // Account.toString()을 사용하여 계좌 정보를 추가 (자동으로 줄바꿈 없이 정보가 들어옴)
	            sb.append(account.toString()).append(lineSeparator);
	        }
	    }
	    
	    // 4. 완료 메시지 추가
	    sb.append("✅ 전체 계좌 리스트를 출력했습니다.").append(lineSeparator);
	    
	    return sb.toString();
	}
	
	
	
	
	public synchronized int getNumberOfCustomers() {
		return customerList.size();
	}

	public synchronized double getTotalBankBalance() {
		double sum = 0;
		for (Account a : accountList) {
			sum += a.getTotalBalance();
		}
		return sum;
	}

	public static void main(String[] args) {
		new BankServer();
	}
	
	
	
	// ------------------- 클라이언트 요청 처리 -------------------

	class ClientHandler implements Runnable {
		Socket clientSocket;
		BankServer server;
		BufferedReader reader;
		PrintWriter writer;

		public ClientHandler(Socket socket, BankServer server) {
			this.clientSocket = socket;
			this.server = server;
		}

		@Override
		public void run() {
			try {
				writer = new PrintWriter(clientSocket.getOutputStream(), true);
				reader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

				String request;
				// 클라이언트가 직접 연결을 끊거나 (readLine()이 null 반환), 
				// IOException이 발생할 때까지 루프를 계속 돌며 명령을 처리합니다.
				while ((request = reader.readLine()) != null) { 
					System.out.println("RECV: " + request);
					String response = processRequest(request);
					System.out.println("SEND: " + response);
					writer.println(response);
				}
				
				// 루프를 빠져나왔다면, 클라이언트가 정상적으로 연결을 종료했음을 의미합니다.
				System.out.println("Client disconnected normally: " + clientSocket.getInetAddress());

			} catch (IOException e) {
				// 통신 중 오류가 발생하면 연결이 끊어진 것으로 처리
				System.out.println("Client disconnected or error occurred: " + e.getMessage());
			} finally {
				// 어떤 경우든 스레드가 종료될 때 소켓을 닫아 자원을 해제합니다.
				try {
					if (reader != null) reader.close();
					if (writer != null) writer.close();
					// ⭐ 수정: ClientHandler가 종료될 때만 소켓을 닫습니다. ⭐
					clientSocket.close(); 
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		private String processRequest(String request) {
			String[] parts = request.split("\\|");
			String command = parts[0];

			switch (command) {
			// 권한 인증 : AUTHENTICATE_USER|userID|password
			case "AUTHENTICATE_USER":
				return server.authenticateUser(parts[1], parts[2]);

				// 신규 고객 추가 : ADD_CUSTOMER|name|id|password|address|phone
			case "ADD_CUSTOMER":
				if (parts.length != 6) return "FAIL|Invalid arguments for ADD_CUSTOMER";
				return server.addCustomer(parts[1], parts[2], parts[3], parts[4], parts[5])
						? "SUCCESS" : "FAIL";

				// 고객 삭제 : DELETE_CUSTOMER|customerID
			case "DELETE_CUSTOMER":
				return server.deleteCustomer(parts[1]) ? "SUCCESS" : "FAIL";

				// 고객 조회 : FIND_CUSTOMER|customerID
			case "FIND_CUSTOMER": {
				Customer customer = server.findCustomer(parts[1]);
				// Customer.toString() 사용
				return (customer != null) ? "SUCCESS|" + customer.toString() : "FAIL|Customer not found.";
			}

			/**
			 * 계좌 추가
			 * 명령 형식: ADD_ACCOUNT|customerID|accountType|initialBalance|param1|param2
			 */
			case "ADD_ACCOUNT": {
				if (parts.length < 6) return "FAIL|Invalid arguments for ADD_ACCOUNT";

				String customerID = parts[1];
				String accountType = parts[2];
				double initialBalance, param1, param2;

				try {
					initialBalance = Double.parseDouble(parts[3]);
					param1 = Double.parseDouble(parts[4]);
					param2 = Double.parseDouble(parts[5]);
				} catch (NumberFormatException e) {
					return "FAIL|Invalid number format for balance, rate, or limit.";
				}

				String newAccNum = server.addAccount(customerID, accountType, initialBalance, param1, param2);

				if (newAccNum != null) {
					return "SUCCESS|새 계좌번호: " + newAccNum;
				} else {
					return "FAIL|고객을 찾을 수 없거나 계좌 생성에 실패했습니다.";
				}
			}

			// 계좌 삭제 : DELETE_ACCOUNT|accountNumber
			case "DELETE_ACCOUNT":
				return server.deleteAccount(parts[1]) ? "SUCCESS" : "FAIL";

				// 계좌 조회 : FIND_ACCOUNT|accountNumber
			case "FIND_ACCOUNT": {
				Account account = server.findAccount(parts[1]);
				return (account != null) ? "SUCCESS|" + account.toString() : "FAIL|Account not found."; // ⭐ toString() 사용
			}

			// 잔액 조회 : FIND_BALANCE|accountNumber
			case "FIND_BALANCE": {
				double balance = server.findbalance(parts[1]);
				return (balance != -1) ? "SUCCESS|" + String.format("%.2f", balance) : "FAIL|Account not found.";
			}

			// 입금 : CREDIT|accountNumber|amount
			case "CREDIT": {
				if (parts.length != 3) return "FAIL|Invalid arguments for CREDIT";
				try {
					double amount = Double.parseDouble(parts[2]);
					server.deposit(parts[1], amount);
					return "SUCCESS";
				} catch (NumberFormatException e) {
					return "FAIL|Invalid amount format.";
				}
			}

			// 출금 : DEBIT|accountNumber|password|amount (ATMClientGUI용)
			case "DEBIT": {
				// ⭐ 수정: 비밀번호 포함, 총 4개 파라미터로 가정 ⭐
				if (parts.length != 4) return "FAIL|Invalid arguments for DEBIT"; 
				try {
					// parts[2]는 비밀번호, parts[3]이 금액
					double amount = Double.parseDouble(parts[3]); 
					String password = parts[2]; // 비밀번호는 받지만 검증은 생략
					
					boolean ok = server.withdraw(parts[1], amount, password);
					return ok ? "SUCCESS" : "FAIL|Insufficient balance or invalid account.";
				} catch (NumberFormatException e) {
					return "FAIL|Invalid amount format.";
				}
			}

			// 계좌 이체 : TRANSFER|fromAccount|toAccount|password|amount
			case "TRANSFER": {
				// ⭐ 수정: 비밀번호 포함, 총 5개 파라미터로 가정 ⭐
				if (parts.length != 5) return "FAIL|Invalid arguments for TRANSFER"; 
				try {
					// parts[3]은 비밀번호, parts[4]가 금액
					double amount = Double.parseDouble(parts[4]); 
					String password = parts[3]; // 비밀번호는 받지만 검증은 생략
					
					boolean ok = server.transfer(parts[1], parts[2], amount, password);
					return ok ? "SUCCESS" : "FAIL|Transfer failed (check accounts or balance).";
				} catch (NumberFormatException e) {
					return "FAIL|Invalid amount format.";
				}
			}

			// 모든 고객 정보 출력
			case "PRINT_CUSTOMLIST":
				return "SUCCESS|" + server.printCustomerList();

				// 모든 계좌 정보 출력
			case "PRINT_ACCOUNTLIST":
				return "SUCCESS|" + server.printAccountList();
				
				// 고객 수 조회
			case "GET_NUM_CUSTOMERS":
				return "SUCCESS|" + server.getNumberOfCustomers();

				// 총 보유 잔고 조회
			case "GET_TOTAL_BALANCE":
				return "SUCCESS|" + String.format("%.2f", server.getTotalBankBalance());

			default:
				return "ERROR|UNKNOWN COMMAND: " + command;
			}
		}
	}
	
	
}