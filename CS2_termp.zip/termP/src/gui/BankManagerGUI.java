package gui;
import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.*;
import javax.swing.text.JTextComponent;

public class BankManagerGUI extends JFrame {
    // ---- 화면 구성 요소 ----
    private JTextArea logArea; // 단일 로그/정보 출력 영역 유지
    private JTextField idField, pwField;
    private JButton loginButton;
    
    // 고객 관련 버튼
    private JButton addCustomerButton, viewCustomerButton, deleteCustomerButton;
    private JButton printCustomerListButton;

    // 계좌 관련 버튼
    private JButton addAccountButton, viewAccountButton, deleteAccountButton;
    private JButton printAccountListButton;

    // 서버 제어/화면 제어 버튼
    private JButton stopButton, clearButton;

    // ---- 네트워크 통신 관련 필드 ----
    private Socket socket;
    private PrintWriter writer;
    private BufferedReader reader;
    private boolean loggedIn = false;

    // 서버 주소 및 포트
    private static final String SERVER_HOST = "localhost";
    private static final int SERVER_PORT = 6000;

    public BankManagerGUI() {
        // 메인 프레임 기본 설정
        setTitle("은행 관리자 GUI");
        setSize(700, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // 화면 중앙 배치

        // -------------------------
        // 1. 로그인 패널 구성 (NORTH)
        // -------------------------
        JPanel loginPanel = new JPanel();
        loginPanel.add(new JLabel("ID:"));
        idField = new JTextField(8);
        loginPanel.add(idField);
        loginPanel.add(new JLabel("PW:"));
        pwField = new JPasswordField(8);
        loginPanel.add(pwField);
        loginButton = new JButton("로그인");
        loginPanel.add(loginButton);
        add(loginPanel, BorderLayout.NORTH);

        // -------------------------
        // 2. 로그 출력 영역(CENTER) - 단일 JTextArea 사용으로 복구
        // -------------------------
        logArea = new JTextArea("로그인 후, 기능 버튼을 사용하여 작업을 수행하세요.");
        logArea.setEditable(false);
        add(new JScrollPane(logArea), BorderLayout.CENTER);


        // -------------------------
        // 3. 버튼 객체 생성
        // -------------------------
        addCustomerButton = new JButton("고객 추가");
        viewCustomerButton = new JButton("고객 조회");
        deleteCustomerButton = new JButton("고객 삭제");
        printCustomerListButton = new JButton("고객 리스트");

        addAccountButton = new JButton("계좌 추가");
        viewAccountButton = new JButton("계좌 조회");
        deleteAccountButton = new JButton("계좌 삭제");
        printAccountListButton = new JButton("계좌 리스트");

        stopButton = new JButton("종료"); // 클라이언트 종료
        clearButton = new JButton("로그 초기화");

        // -------------------------
        // 4. 하단 버튼 패널 구성 (SOUTH)
        // -------------------------
        JPanel customerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        customerPanel.add(addCustomerButton);
        customerPanel.add(viewCustomerButton);
        customerPanel.add(deleteCustomerButton);
        customerPanel.add(printCustomerListButton);

        JPanel accountPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        accountPanel.add(addAccountButton);
        accountPanel.add(viewAccountButton);
        accountPanel.add(deleteAccountButton);
        accountPanel.add(printAccountListButton);

        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        controlPanel.add(stopButton);
        controlPanel.add(clearButton);

        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.Y_AXIS));
        bottomPanel.add(customerPanel);
        bottomPanel.add(accountPanel);
        bottomPanel.add(controlPanel);
        add(bottomPanel, BorderLayout.SOUTH);

        // 로그인 전에는 관리 기능 버튼들을 비활성화
        setButtonsEnabled(false);

        // -------------------------
        // 5. 이벤트 리스너 설정
        // -------------------------
        loginButton.addActionListener(e -> authenticateManager());
        addCustomerButton.addActionListener(e -> addCustomer());
        viewCustomerButton.addActionListener(e -> viewCustomer());
        deleteCustomerButton.addActionListener(e -> deleteCustomer());
        printCustomerListButton.addActionListener(e -> printCustomerList());

        addAccountButton.addActionListener(e -> addAccount());
        viewAccountButton.addActionListener(e -> viewAccount());
        deleteAccountButton.addActionListener(e -> deleteAccount());
        printAccountListButton.addActionListener(e -> printAccountList());

        clearButton.addActionListener(e -> logArea.setText(""));
        stopButton.addActionListener(e -> stopClient());

        // 6. 프로그램 시작 시 서버 연결 시도
        connectToServer();
    }

    /**
     * 서버와 소켓 연결을 수행하는 메서드
     */
    private void connectToServer() {
        try {
            socket = new Socket(SERVER_HOST, SERVER_PORT);
            writer = new PrintWriter(socket.getOutputStream(), true); // auto-flush 설정
            reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            appendLog("✅ 서버에 연결됨: " + SERVER_HOST + ":" + SERVER_PORT);
        } catch (IOException e) {
            appendLog("❌ 서버 연결 실패: " + e.getMessage());
        }
    }
    
    /**
     * 서버에 요청을 전송하고 응답을 받는 통신 헬퍼 메서드
     */
    private String sendRequest(String request) {
        if (writer == null || reader == null || (socket != null && socket.isClosed())) {
            appendLog("⚠️ 오류: 서버 연결이 끊어졌습니다. 연결을 재시도합니다.");
            connectToServer();
            if (writer == null || reader == null || (socket != null && socket.isClosed())) return null;
        }
        try {
            // 요청 전송
            writer.println(request);
            appendLog("⬆️ SEND: " + request);
            
            // 응답 수신
            String response = reader.readLine();
            appendLog("⬇️ RECV: " + response);
            return response;
        } catch (IOException e) {
            appendLog("❌ 통신 오류: " + e.getMessage());
            return null;
        }
    }

    /**
     * 로그 창에 문자열 한 줄을 추가하는 유틸리티 메서드
     * (EDT 안전을 위해 SwingUtilities.invokeLater() 적용 유지)
     */
    private void appendLog(String msg) {
        SwingUtilities.invokeLater(() -> {
            logArea.append(msg + "\n");
            // 스크롤을 항상 가장 아래로 내림
            logArea.setCaretPosition(logArea.getDocument().getLength());
        });
    }

    /**
     * 관리자 로그인 처리 메서드
     */
    private void authenticateManager() {
        String id = idField.getText().trim();
        String pw = new String(((JPasswordField) pwField).getPassword()).trim();

        if (id.isEmpty() || pw.isEmpty()) {
            appendLog("⚠️ ID와 비밀번호를 입력하세요.");
            return;
        }
        
        String resp = sendRequest("AUTHENTICATE_USER|" + id + "|" + pw);
        
        if (resp == null) {
            appendLog("❌ 서버 응답을 받지 못했습니다.");
            return;
        }

        if ("MANAGER".equals(resp)) {
            loggedIn = true;
            appendLog("🔑 관리자 인증 성공! 기능 활성화.");
            
            // 로그인 성공 시 로그 영역 초기화 및 안내 메시지 설정
            SwingUtilities.invokeLater(() -> {
                logArea.setText("🔑 관리자 로그인 성공. 기능이 활성화되었습니다.");
            });
            
            setButtonsEnabled(true);
            
            // 로그인 성공 후 로그인 영역 비활성화
            idField.setEnabled(false);
            pwField.setEnabled(false);
            loginButton.setEnabled(false);
        } else {
            loggedIn = false;
            appendLog("❌ 관리자 인증 실패. (응답: " + resp + ")");
            setButtonsEnabled(false);
        }
    }

    /**
     * 로그인 이후 기능 버튼 활성/비활성 제어
     */
    private void setButtonsEnabled(boolean enabled) {
        addCustomerButton.setEnabled(enabled);
        viewCustomerButton.setEnabled(enabled);
        deleteCustomerButton.setEnabled(enabled);
        printCustomerListButton.setEnabled(enabled);

        addAccountButton.setEnabled(enabled);
        viewAccountButton.setEnabled(enabled);
        deleteAccountButton.setEnabled(enabled);
        printAccountListButton.setEnabled(enabled);

        stopButton.setEnabled(true); // 클라이언트 종료는 항상 가능하게
    }

    // ------------------- 고객 관리 기능 -------------------

    /**
     * 고객 추가 기능
     */
    private void addCustomer() {
        JTextField nameField = new JTextField();
        JTextField cidField = new JTextField();
        JTextField pwField = new JPasswordField(); 
        JTextField addrField = new JTextField();
        JTextField phField = new JTextField();

        Object[] params = {
            "이름", nameField,
            "아이디", cidField,
            "비밀번호", pwField,
            "주소", addrField,
            "전화", phField
        };

        int res = JOptionPane.showConfirmDialog(this, params, "고객 추가", JOptionPane.OK_CANCEL_OPTION);
        if (res == JOptionPane.OK_OPTION) {
            String cmd = String.format("ADD_CUSTOMER|%s|%s|%s|%s|%s",
                nameField.getText(), cidField.getText(), ((JTextComponent)pwField).getText(),
                addrField.getText(), phField.getText());

            String resp = sendRequest(cmd);
            if (resp != null) {
                appendLog("고객 추가 요청 결과: " + resp);
                JOptionPane.showMessageDialog(this, "고객 추가 요청 결과: " + resp);
            }
        }
    }

    /**
     * 고객 조회 기능 (조회 결과를 로그 창에 상세 출력)
     */
    private void viewCustomer() {
        String cid = JOptionPane.showInputDialog(this, "검색할 고객 아이디?");
        if (cid != null && !cid.isEmpty()) {
            String resp = sendRequest("FIND_CUSTOMER|" + cid);
            if (resp != null) {
                if (resp.startsWith("SUCCESS|")) {
                    String dataPart = resp.substring("SUCCESS|".length());
                    
                    // 로그 영역에 제목 추가 및 상세 정보 출력
                    appendLog("--- [고객 상세 정보] 고객 ID: " + cid + " ---"); 
                    for (String line : dataPart.split("\n")) {
                        appendLog("  " + line);
                    }
                    appendLog("--------------------------------------");
                    
                    JOptionPane.showMessageDialog(this, "고객 상세 정보:\n" + dataPart);
                    
                } else {
                    appendLog("❌ 고객 조회 실패: " + resp);
                    JOptionPane.showMessageDialog(this, "고객 조회 실패:\n" + resp);
                }
            }
        }
    }

    /**
     * 고객 삭제 기능
     */
    private void deleteCustomer() {
        String cid = JOptionPane.showInputDialog(this, "삭제할 고객 아이디?");
        if (cid != null && !cid.isEmpty()) {
            int confirm = JOptionPane.showConfirmDialog(this, "고객 ID: " + cid + "와 연결된 모든 계좌가 삭제됩니다. 계속하시겠습니까?", "고객 삭제 확인", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                String resp = sendRequest("DELETE_CUSTOMER|" + cid);
                if (resp != null) {
                    appendLog("고객 삭제 요청 결과: " + resp);
                    JOptionPane.showMessageDialog(this, "고객 삭제 요청 결과: " + resp);
                }
            }
        }
    }

    /**
     * 전체 고객 리스트 요청
     */
    private void printCustomerList() {
        String resp = sendRequest("PRINT_CUSTOMLIST");

        if (resp == null) {
            SwingUtilities.invokeLater(() -> {
                logArea.setText("=== 고객 리스트 불러오기 실패 (통신 오류) ===");
            });
            return;
        }

        if (resp.startsWith("SUCCESS|")) {
            String dataPart = resp.substring("SUCCESS|".length());
            // 서버에서 "---CUST-SEP---"를 "\n\n"으로 대체하여 여러 줄로 만듭니다.
            String formattedData = dataPart.replace("---CUST-SEP---", System.lineSeparator() + System.lineSeparator());
            
            final String finalData;
            if (formattedData.trim().isEmpty()) {
                finalData = "=== 전체 고객 리스트 ===\n" + "등록된 고객이 없습니다.";
            } else {
                finalData = "=== 전체 고객 리스트 ===\n" + formattedData;
            }

            SwingUtilities.invokeLater(() -> {
                logArea.setText(finalData);
            });
            appendLog("✅ 전체 고객 리스트를 출력했습니다.");
        } else {
            final String finalResp = resp;
            SwingUtilities.invokeLater(() -> {
                logArea.setText("=== 고객 리스트 불러오기 오류 ===\n" + finalResp);
            });
            appendLog("❌ 고객 리스트 요청 실패.");
        }
    }

    // ------------------- 계좌 관리 기능 -------------------

    /**
     * 계좌 추가 기능
     */
    private void addAccount() {
        JTextField cidField = new JTextField();
        JComboBox<String> typeBox = new JComboBox<>(new String[]{"Checking", "Savings"});
        JTextField initialBalanceField = new JTextField("0.0");
        JTextField rateField = new JTextField("0.03");
        JTextField maxTransField = new JTextField("100000.0");

        Object[] params = {
            "고객 아이디", cidField,
            "계좌유형", typeBox,
            "초기 잔액", initialBalanceField,
            "이자율 (Savings용)", rateField,
            "한도 (Savings용)", maxTransField
        };

        int res = JOptionPane.showConfirmDialog(this, params, "계좌 추가", JOptionPane.OK_CANCEL_OPTION);
        
        if (res == JOptionPane.OK_OPTION) {
            String customerID = cidField.getText().trim();
            String accountType = (String) typeBox.getSelectedItem();
            
            if (customerID.isEmpty()) {
                JOptionPane.showMessageDialog(this, "고객 아이디를 입력해야 합니다.", "입력 오류", JOptionPane.ERROR_MESSAGE);
                return;
            }

            double initialBalance, param1, param2;
            try {
                initialBalance = Double.parseDouble(initialBalanceField.getText());
                if (initialBalance < 0) throw new NumberFormatException("초기 잔액은 0 이상이어야 합니다.");
                param1 = Double.parseDouble(rateField.getText());
                param2 = Double.parseDouble(maxTransField.getText());
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "금액, 이자율, 한도는 유효한 숫자여야 합니다. \n오류: " + e.getMessage(), "입력 오류", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // ADD_ACCOUNT|고객ID|계좌유형|초기잔액|이자율|한도
            String cmd = String.format("ADD_ACCOUNT|%s|%s|%.2f|%.2f|%.2f",
                        customerID, accountType, initialBalance, param1, param2);
            
            String resp = sendRequest(cmd);
            if (resp != null) {
                appendLog("계좌 추가 요청 결과: " + resp);
                JOptionPane.showMessageDialog(this, "계좌 추가 요청 결과: " + resp);
            }
        }
    }

    /**
     * 계좌 조회 기능 (조회 결과를 로그 창에 상세 출력)
     */
    private void viewAccount() {
        String accNum = JOptionPane.showInputDialog(this, "조회할 계좌번호?");
        if (accNum != null && !accNum.isEmpty()) {
            String resp = sendRequest("FIND_ACCOUNT|" + accNum);
            if (resp != null) {
                if (resp.startsWith("SUCCESS|")) {
                    String dataPart = resp.substring("SUCCESS|".length());
                    
                    // 로그 영역에 제목 추가 및 상세 정보 출력
                    appendLog("--- [계좌 상세 정보] 계좌번호: " + accNum + " ---");
                    for (String line : dataPart.split("\n")) {
                        appendLog("  " + line);
                    }
                    appendLog("--------------------------------------");
                    
                    JOptionPane.showMessageDialog(this, "계좌 상세 정보:\n" + dataPart);
                    
                } else {
                    appendLog("❌ 계좌 조회 실패: " + resp);
                    JOptionPane.showMessageDialog(this, "계좌 조회 실패:\n" + resp);
                }
            }
        }
    }

    /**
     * 계좌 삭제 기능
     */
    private void deleteAccount() {
        String accNum = JOptionPane.showInputDialog(this, "삭제할 계좌번호?");
        if (accNum != null && !accNum.isEmpty()) {
            int confirm = JOptionPane.showConfirmDialog(this, "계좌번호: " + accNum + "를 삭제하시겠습니까?", "계좌 삭제 확인", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                String resp = sendRequest("DELETE_ACCOUNT|" + accNum);
                if (resp != null) {
                    appendLog("계좌 삭제 요청 결과: " + resp);
                    JOptionPane.showMessageDialog(this, "계좌 삭제 요청 결과: " + resp);
                }
            }
        }
    }

    /**
     * 전체 계좌 리스트 요청
     */
    private void printAccountList() {
        // 1. 서버에 요청을 보냅니다.
        String resp = sendRequest("PRINT_ACCOUNTLIST");

        if (resp == null) {
            SwingUtilities.invokeLater(() -> {
                logArea.setText("=== 계좌 리스트 불러오기 실패 (통신 오류) ===");
            });
            return;
        }

        if (resp.startsWith("SUCCESS|")) {
            // 2. SUCCESS 접두어를 제외한 나머지 부분 (이미 서버에서 완벽하게 포맷된 데이터)을 가져옵니다.
            String dataPart = resp.substring("SUCCESS|".length());
            
            // 3. ⭐ 수정: 서버가 보낸 포맷된 문자열을 그대로 로그 영역에 출력합니다. ⭐
            String formattedData = dataPart.replace("[NL]", System.lineSeparator());
            final String finalData = formattedData; 
            
            SwingUtilities.invokeLater(() -> {
                logArea.setText(finalData);
            });
           
        } else {
            final String finalResp = resp;
            SwingUtilities.invokeLater(() -> {
                logArea.setText("=== 계좌 리스트 불러오기 오류 ===\n" + finalResp);
            });
            appendLog("❌ 계좌 리스트 요청 실패.");
        }
    }
    
    // ------------------- 클라이언트 종료 -------------------

    /**
     * 클라이언트 종료 기능 (서버 연결 닫기)
     */
    private void stopClient() {
        appendLog("클라이언트 종료 요청.");
        try {
            if (socket != null && !socket.isClosed()) {
                socket.close();
            }
        } catch (IOException e) {
            appendLog("종료 중 오류: " + e.getMessage());
        }
        System.exit(0);
    }

    /**
     * 프로그램 시작점
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new BankManagerGUI().setVisible(true));
    }
}